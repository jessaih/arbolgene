<?php
    require_once 'util/SecurityValidator.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title>Administra Descendientes</title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="assets/css/responsive.css">
	<style>
		.cart-table a:hover{
			color: #F28123;
		}
		
		.formlabel {
			font-weight: bold;
			text-align: right;
		} 
		
		.required{
			color: red;
		}
		
		td.product-image-edit img {
			max-width: 175px;
			-webkit-box-shadow: none;
			box-shadow: none;
			margin-bottom: 0;
		}
                
                #ancestro_datos_table thead{
                    font-size: 22px; 
                    font-weight: 600; 
                    text-align: center;
                }
                
                #ancestro_datos_table td{
                    padding: 15px;
                }
                
		
	</style>
</head>
<body ng-app="myApp" ng-controller="MyCtrl">
	
	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="assets/img/logo.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu" style="text-align:left;">
							<ul>
								<li><a href="visualiza-parejas-origen.php">Visualiza Parejas Origen</a></li>
								<li>&nbsp;</li>
                                                                <li><a href="controller/SecurityController.php">Cierra Sesión</a></li>
								<li>&nbsp;</li>
							</ul>
						</nav>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->

	<!-- search area -->
	
	<!-- end search arewa -->

	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="breadcrumb-text">
						<p>Administrar</p>
						<h1>Descendientes</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end breadcrumb section -->

	<!-- single product -->
	<div class="single-product mt-150 mb-150" >
		<div class="container">
                        <div ng-hide="viewAncestrosCheck">
                            <a ng-click='viewAncestros()' class='cart-btn'><i class='fas fa-pen' title='Editar' ></i>Ver ancestros</a>
                        </div>
                        <br/><br/>
			<div class="row">
				<div class="col-md-5">
					<div class="single-product-img">
						<img id="ancestro_img_principal" src="assets/img/album/no_img.png" alt='' />
						<p id="ancestro_nota_principal" style="font-weight: bold ;text-align: center;"> </p>
					</div>
				</div>
				<div class="col-md-7">
					<div id="ancestro_nombres" class="single-product-content">
                                        </div>
					<div id="ancestro_datos" class="single-product-content">
                                            <table id="ancestro_datos_table" border="0pt" style="width:100%;" >
                                                <thead>
                                                    <tr>
                                                        <td class="product-image-edit">
                                                            <img id="img_eo" src='assets/img/album/no_img.png' alt=''>
                                                        </td>
                                                        <td ></td>
                                                        <td class="product-image-edit">
                                                                <img id="img_ea" src='assets/img/album/no_img.png' alt=''>
                                                        </td>
                                                    </tr>                                                    
                                                    <tr>
                                                        <td id="nombre_completo_eo" ></td>
                                                        <td style="background-color: #fff3f5">y</td>
                                                        <td id="nombre_completo_ea"></td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!--<tr><td colspan="3"><br/></td></tr>-->
                                                    <tr style="font-weight:bold; text-align: justify;">
                                                        <td id="notas_eo" >-</td>
                                                        <td ></td>
                                                        <td id="notas_ea">-</td>
                                                    </tr>
                                                <tbody>
                                                <tfoot>
                                                    <tr> 
                                                        <td colspan="3" align='center'>
                                                            <a ng-click='editPareja()' class='cart-btn'><i class='fas fa-pen' title='Editar'></i> Editar</a> 
                                                        </td>  
                                                    </tr>
                                                </tfoot>
                                            </table>
					</div>
				</div>
			</div>			
		</div>
	</div>
	<!-- end single product -->

	<!-- Seccion donde se mostrara todas las imagenes de la pareja de una manera ordenada en una cuadricula de 3 * N -->
	<div id = "product-section" class="product-section mt-150 mb-150" style="display:none">
		<div class="container">
                        <div id="ancestro_galeria" class="row product-lists">
				<div class="col-lg-4 col-md-6 text-center">
					<div class="single-product-item">
						<div class="product-image">
							<img src="assets/img/album/no_img.png" alt=""/>
						</div>
						<h3>No hay mas imágenes que mostrar</h3>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end products -->
        <!--<br/><br/><br/><br/>-->
	<!-- cart -->
	<div class="cart-section mt-150 mb-150">
		<div class="container">
			<div class="row">
				<div class="section-title">	
					<h3 style="text-align:center"><span class="orange-text">Sus</span> Descendientes</h3>
				</div>
				<table class="cart-table">
					<thead class="cart-table-head">
						<tr class="table-head-row" style="font-weight:bold;">
							<th class="product-index">#</th>
							<th class="product-image">Imagen</th>
							<th class="product-name">Nombre</th>
							<th class="product-lastname">Apellido</th>
							<th class="product-number"># de hijo/a</th>
							<th class="product-notas">Notas</th>
							<th class="product-operations" colspan="3">Operaciones</th>
						</tr>
					</thead>
					<tbody id="descendientes" >
						<tr class="table-body-row" id="tr{{$index}}" style="text-align: center; " ng-repeat="descendiente in descendientes track by $index"> 
							<td class="product-index"> {{$index +1}}</td>  
							<td class="product-image" style="vertical-align: middle;">
								<img id="img{{$index}}" ng-if="!descendiente.ruta_img" ng-src="assets/img/album/no_img.png" alt="" />	
								<img id="img{{$index}}" ng-if="descendiente.ruta_img" ng-src="assets/img/album/{{descendiente.ruta_img}}" alt="" />
							</td> 
							<td class="product-name"><b> {{descendiente.nombres}} </b></td> 
							<td class="product-lastname"><b> {{descendiente.apellidos}} </b></td> 
							<td class="product-number"> {{descendiente.numero_hermano}} </td> 
							<td class="product-notas"> {{descendiente.notas}} </td> 
							<td class="product-edit"><a ng-click="modifyNewDescendiente($index, descendiente.descendiente_id)"  data-toggle="modal" data-target="#myModal"><i class='fas fa-pen' title="Editar"></i></a></td> 
							<td class="product-remove"><a ng-click="delete(descendiente.descendiente_id, descendiente.nombres, descendiente.apellidos)"><i class='fas fa-trash' title="Eliminar"></i></a></td> 
							<td class="product-view">
								<a ng-if="descendiente.numero_parejas > 0" ng-click="viewDescendientes(descendiente.familiar_id_fk)"><i class='fas fa-eye' title="Ver descendientes"></i></a>
								<a ng-if="descendiente.numero_parejas == 0" ng-click="addPareja(descendiente.familiar_id_fk)"><i class='fas fa-user-plus' title="Agregar Pareja"></i></a>
							</td>
						</tr>
					</tbody>					
					<tfoot>					
						<tr style="text-align: center; border: solid; border-top-width: 2px; border-color: #efefef;">
							<td class="add-item" colspan="9" style="font-weight: bold; ">
								<a ng-click="addNewDescendiente()" data-toggle="modal" data-target="#myModal" >
									<i class='fas fa-plus' title="Agregar Nuevo Descendiente"></i>
								</a>
							</td>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
	</div>
	<!-- end cart -->
	<!-- <i class='fas fa-check' title="Confirmar">
	<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" ng-click="showAddSection()">Open Modal</button> -->

	<!-- Modal -->
	<div class="modal fade" id="myModal" role="dialog" style="display: none;">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header" >
					<h4 class="modal-title" id = "modal-title"></h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<form name="addDescendienteForm" id="addDescendienteForm" novalidate>
						<table cellpadding="12">
							<tr ng-if="!addNewDescendienteCheck" >
								<td colspan="2" class="product-image-edit" style="text-align: center;">
									<img ng-src="{{modifyImage}}" alt=""/>
								</td>
							</tr>
							<tr>
								<td class = "formlabel"><label for="newDescendienteImg">Imagen</label></td>
								<td>
									<input id="newDescendienteImg" name="newDescendienteImg" ng-model="newDescendienteImg" type = "file"  />
								</td>
							</tr>
							<tr>
								<td class = "formlabel"><label for="newDescendienteNombre">Nombre</label> <span class="required"> *</span></td>
								<td> 
									<input id="newDescendienteNombre" name="newDescendienteNombre" ng-model="newDescendienteNombre" type="text" required /> 
									<label class="required" ng-show="addDescendienteForm.newDescendienteNombre.$dirty && addDescendienteForm.newDescendienteNombre.$error.required">* Campo Requerido</label>
								</td>
							</tr>								
							<tr>
								<td class = "formlabel"><label for="newDescendienteApellido">Apellidos</label><span class="required"> *</span></td>
								<td> 
									<input id="newDescendienteApellido" name="newDescendienteApellido" ng-model="newDescendienteApellido" type="text" required/> 
									<label class="required" ng-show="addDescendienteForm.newDescendienteApellido.$dirty && addDescendienteForm.newDescendienteApellido.$error.required">* Campo Requerido</label>
								</td>
							</tr>								
							<tr>
								<td class = "formlabel"><label for="newDescendienteNumero"># de Hijo/a</label><span class="required"> *</span></td>
								<td> 
									<input id="newDescendienteNumero" name="newDescendienteNumero" ng-model="newDescendienteNumero" type="number" required/> 
									<label class="required" ng-show="addDescendienteForm.newDescendienteNumero.$dirty && addDescendienteForm.newDescendienteNumero.$error.required">* Campo Requerido </label>
								</td>
							</tr>
							<tr>
								<td class = "formlabel"><label for="newDescendienteNotas">Notas</label></td>
								<td> 
									<textarea id="newDescendienteNotas" name="newDescendienteNotas" ng-model="newDescendienteNotas" rows="6" cols="40" style="resize: none;"> 
									</textarea>
								</td>
							</tr>								
							<tr>
								<td > </td>
								<td class = "formlabel"> 
									<button type="submit" ng-click="add()" ng-disabled="addDescendienteForm.$invalid" ng-if="addNewDescendienteCheck">Crear</button> 
									<button type="submit" ng-click="modify()" ng-disabled="addDescendienteForm.$invalid" ng-if="!addNewDescendienteCheck">Actualizar</button> 
									&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset"/> 
								</td>
							</tr>
						</table>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" id="modal-dismiss" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</div>
	</div>
	<!-- logo carousel -->

	<!-- end logo carousel -->

	<!-- footer -->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="footer-box about-widget">
						<h2 class="widget-title">Acerca</h2>
						<p>
						Grupo de todos los herederos de los 6 hermanos González González nacidos en Tzurumuato hoy Pastor Ortiz, Michoacán.
						Nuestros ancestros son:
						<br/><br/>
						Teodomira, Eulalia, Josefa, Antonio, Francisca y Maria nacidos entre 1875 y 1890, todos hijos de Francisco González y Francisca González</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 class="widget-title">Contactáme</h2>
						<ul>
							<li></li>
							<li>Email: jessaigh@gmail.com</li>
							<li>Whatsapp</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end footer -->
	
	<!-- copyright -->
		<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2023 - <a href="https://imransdesign.com/">Imran Hossain</a>,  All Rights Reserved.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->
	<!-- jquery -->
	<script src="assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="assets/js/main.js"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.8.3/angular.js"></script>
	
	<script src="assets/angular/arbol-admin.js"></script>		
</body>

</html>